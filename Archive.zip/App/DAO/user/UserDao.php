<?php
interface UserDao
{
    public function getDataPaciente($buscador, $procedencia, $nivel);
}
