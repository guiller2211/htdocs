
<head>
    <title>Resultados</title>
</head>


<body style="background-color:#004173">
    <div align=center>
        <h1>
            <p style="color:white" ;>Lo sentimos!!!</p>

            <p style="color:white">Hubo un error,</p>
            <p style="color:white"> regresa a nuestro inicio</p>
            <a class="btn btn-primary" href="/">volver</a>

        </h1>
        <a href="/"><img src="/ipleones/labMuest/public/img/logo.png" width="500"></a>
    </div>
</body>