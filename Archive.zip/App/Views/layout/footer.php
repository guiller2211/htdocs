</main>
</body>

<footer>
    <div class="container">
        <div class="column">
            <p>Dirección: Arturo Prat 269 Santiago</p>
            <p>Teléfono de contacto: +56 9 12345678</p>
            <p>Email: <a href="mailto:Labmuest@labmuest.cl">Labmuest@labmuest.cl</a></p>
            <p>&copy; 2024 Labmuest | Todos los derechos reservados</p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="/ipleones/labMuest/public/js/formularios.js"></script>
<script src="/ipleones/labMuest/public/js/global.js"></script>
</html>